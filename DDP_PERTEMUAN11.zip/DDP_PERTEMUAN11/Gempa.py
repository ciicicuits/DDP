#membuat kelas Gempa
class Gempa :

    jumlahGempa = 0

    def __init__(self, skala, lokasi):
            self.skala = skala
            self.lokasi = lokasi
            Gempa.jumlahGempa +=1

    def dampak(self):
        if self.skala < 2:
            dampak = 'Gempa Tidak Terasa'
        elif self.skala >= 2 and self.skala < 4:
            dampak = 'Gempa Bangunan Retak-retak' 
        elif self.skala >= 4 and self.skala < 6:
            dampak = 'Gempa Bangunan Roboh'
        elif self.skala >= 6:
            dampak = 'Gempa Bangunan Roboh Dan Berpotensi Tsunami'
        print(f'Gempa di lokasi {self.lokasi} dengan skala {self.skala}, berpotensi {dampak}')

